#include "lid.h"
enum lid_mode lid_mode = LID_MODE_AID;
