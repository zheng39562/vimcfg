enum lid_mode
  {
    LID_MODE_AID,
    LID_MODE_EID,
    LID_MODE_GID,
    LID_MODE_LID
  };

extern enum lid_mode lid_mode;
